// document.addEventListener('DOMContentLoaded', () => {
//     const chatMessages = document.getElementById('chat-messages');
//     const chatInput = document.getElementById('chat-input');
//     const sendButton = document.getElementById('send-button');

//     console.log('DOM Loaded');

//     // Load chat history from local storage
//     const savedMessages = JSON.parse(localStorage.getItem('chatHistory')) || [];
//     savedMessages.forEach(addMessage);

//     // Handle sending messages
//     sendButton.addEventListener('click', sendMessage);
//     chatInput.addEventListener('keypress', (e) => {
//         if (e.key === 'Enter') sendMessage();
//     });

//     async function sendMessage() {
//         const message = chatInput.value.trim();
//         if (!message) return;

//         addMessage({ sender: "user", text: message });
//         chatInput.value = '';

//         try {
//             // Send message to Flask API
//             const response = await fetch('/chat', {
//                 method: 'POST',
//                 headers: { 'Content-Type': 'application/json' },
//                 body: JSON.stringify({ message })
//             });

//             const data = await response.json();
//             addMessage({ sender: "bot", text: data.response || "Sorry, I didn't understand that." });

//         } catch (error) {
//             console.error("Error fetching response:", error);
//             addMessage({ sender: "bot", text: "Error: Unable to connect to chatbot." });
//         }
//     }

//     function addMessage({ sender, text }) {
//         const messageElement = document.createElement('div');
//         messageElement.classList.add('message', sender);
//         const messageContent = document.createElement('div');
//         messageContent.classList.add('message-content');
//         messageContent.textContent = text;
//         messageElement.appendChild(messageContent);
//         chatMessages.appendChild(messageElement);
//         chatMessages.scrollTop = chatMessages.scrollHeight;

//         // // Save chat history
//         // savedMessages.push({ sender, text });
//         // localStorage.setItem('chatHistory', JSON.stringify(savedMessages));
//     }
// });

document.addEventListener('DOMContentLoaded', () => {
    const chatMessages = document.getElementById('chat-messages');
    const chatInput = document.getElementById('chat-input');
    const sendButton = document.getElementById('send-button');
    const clearButton = document.getElementById('clear-button'); // 👈 New Clear Button

    console.log('DOM Loaded');

    // Load chat history from local storage
    const savedMessages = JSON.parse(localStorage.getItem('chatHistory')) || [];
    savedMessages.forEach(addMessage);

    // Handle sending messages
    sendButton.addEventListener('click', sendMessage);
    chatInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') sendMessage();
    });

    // Handle clearing chat
    clearButton.addEventListener('click', clearChat);
    

    async function sendMessage() {
        const message = chatInput.value.trim().toLowerCase();
        if (!message) return;
    
        addMessage({ sender: "user", text: message });
        chatInput.value = '';
        
        const lowerMessage = message.toLowerCase();

// Smart trigger for creator-related questions
const creatorKeywords = ["create", "developer", "built", "developed", "made"];
const subjectKeywords = ["you","your", "bot", "chatbot", "assistant", "this"];

const mentionsCreation = creatorKeywords.some(word => lowerMessage.includes(word));
const mentionsBot = subjectKeywords.some(word => lowerMessage.includes(word));

if (mentionsCreation && mentionsBot) {
    addMessage({ sender: "bot", text: "I was created by Gurcyber Singh, Piyush Prakash and Harleen Kaur💡" });
    return;
}

    
        const allowedGreetings = ["hi", "hello", "hey"];
        const healthKeywords = [
            "headache", "fever", "cough", "cold", "pain", "diabetes", "bp", "blood pressure",
            "medicine", "health", "treatment", "symptom", "vomiting", "nausea", "flu", "injury",
            "infection", "rash", "asthma", "covid", "appointment", "doctor", "nurse", "clinic",
            "symptom","condition","illness","disease","disorder","diagnosis","treatment","prescription",
            "medication","injury","infection","therapy","health issue","emergency","side effects","checkup",
            "pain","fever","fatigue","nausea","headache","cough","rash","vomiting","allergy","swelling","dizziness",
            "shortness of breath","blood pressure","diabetes","asthma","mental health","anxiety","depression","cardiology",
            "neurology","dermatology","orthopedic","gynecology","pediatrics","oncology","urology","ENT","gastroenterology","masturbation" ,"fever", "cough", "cold", "headache", "stomach ache", "pain", "dizziness",
            "fatigue", "nausea", "vomiting", "rash", "infection", "swelling", "breathing problem",
            "blood pressure", "diabetes", "heart rate", "allergy", "chest pain", "sore throat",
            "injury", "burn", "fracture", "symptom", "diagnose", "treatment", "disease"

        ];
        
        // Check if it's a greeting or contains a health keyword
        const isGreeting = allowedGreetings.includes(message);
        const isHealthRelated = healthKeywords.some(keyword => message.includes(keyword));
        
        if (!isGreeting && !isHealthRelated) {
            addMessage({ sender: "bot", text: "I'm here to assist with health-related questions only." });
            return;
        }
    
        try {
            const response = await fetch('/chat', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ message })
            });
    
            const data = await response.json();

// Remove all asterisks from the response
const cleanText = (data.response || "Sorry, I didn't understand that.").replace(/\*/g, '');

addMessage({ sender: "bot", text: cleanText });

    
        } catch (error) {
            console.error("Error fetching response:", error);
            addMessage({ sender: "bot", text: "Error: Unable to connect to chatbot." });
        }
    }
    

    // async function sendMessage() {
    //     const message = chatInput.value.trim();
    //     if (!message) return;

    //     addMessage({ sender: "user", text: message });
    //     chatInput.value = '';

    //     try {
    //                     // Send message to Flask API
    //                     const response = await fetch('/chat', {
    //                         method: 'POST',
    //                         headers: { 'Content-Type': 'application/json' },
    //                         body: JSON.stringify({ message })
    //                     });
            
    //                     const data = await response.json();
    //                     addMessage({ sender: "bot", text: data.response || "Sorry, I didn't understand that." });
            
    //                 } catch (error) {
    //                     console.error("Error fetching response:", error);
    //                     addMessage({ sender: "bot", text: "Error: Unable to connect to chatbot." });
    //                 }
    // }

    function addMessage({ sender, text }) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message', sender);
        const messageContent = document.createElement('div');
        messageContent.classList.add('message-content');
        messageContent.textContent = text;
        messageElement.appendChild(messageContent);
        chatMessages.appendChild(messageElement);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function clearChat() {
        // Clear messages from the chat UI
        chatMessages.innerHTML = '';

        // Clear localStorage if using it
        localStorage.removeItem('chatHistory');
    }
});

//voice reco
const voiceButton = document.querySelector('.voice-button');
const chatInput = document.getElementById('chat-input');

// Web Speech API
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

if (SpeechRecognition) {
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.continuous = false;
    recognition.interimResults = false;

    voiceButton.addEventListener('click', () => {
        recognition.start();
        voiceButton.textContent = "🎙️ Listening...";
    });

    recognition.addEventListener('result', (event) => {
        const transcript = event.results[0][0].transcript;
        chatInput.value = transcript;
        voiceButton.textContent = "🎙️";
    });

    recognition.addEventListener('end', () => {
        voiceButton.textContent = "🎙️";
    });

    recognition.addEventListener('error', () => {
        voiceButton.textContent = "🎙️";
        alert("Voice recognition error or not supported.");
    });
} else {
    voiceButton.disabled = true;
    voiceButton.title = "Speech recognition not supported in this browser.";
}


